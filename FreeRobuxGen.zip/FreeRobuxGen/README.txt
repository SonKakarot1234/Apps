How to use the program:
1. Run the "FreeRobuxGen" .exe file
2. Input the desired amount of robux in the first field
3. Input your username in the second field
4. Click the "GENERATE" button and watch the magic happen :)

NOTE: Developer (ItsXeno286) is not responsible for any harm done to your computer. Run this program at your own risk.