@echo off
title: Zip Password Cracker

if not exist "C:\Program Files\7-Zip" (
    echo 7-zip is not installed!
    pause
    exit
)

set /p archive="Enter Archive: "
if not exist "%archive%" (
    echo Archive not found!
    pause
    exit
)

set /p wordlist="Enter Wordlist: "
if not exist "%wordlist%" (
    echo Wordlist not found!
    pause
    exit
)

for /f %%a in (%wordlist%) do (
    set pass=%%a
    call :attempt
)
echo No passwords found
pause
exit
:attempt
"C:\Program Files\7-Zip\7z.exe" x -p%pass% "%archive%" -o"Cracked zip" -y >nul 2>&1
echo Cracking...
if /I %errorlevel% EQU 0 (
    echo Password Found: %pass%
    pause
    exit
)