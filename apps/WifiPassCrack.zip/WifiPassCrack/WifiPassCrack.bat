@echo off
title Wifi Password Cracker
color A

setlocal enabledelayedexpansion

for /f "tokens=2 delims=:" %%a in ('netsh wlan show profile') do (
    set "wifi_name=%%a"
    set "wifi_name=!wifi_name:~1!"
    set "wifi_pwd=NOT FOUND"
    for /f "tokens=2 delims=:" %%b in ('netsh wlan show profile name^="!wifi_name!" key^=clear ^| findstr /C:"Key Content"') do (
        set "wifi_pwd=%%b"
        set "wifi_pwd=!wifi_pwd:~1!"
    )
    echo Profile: !wifi_name! - Password: !wifi_pwd!
)
echo.
echo Scan Complete.
pause