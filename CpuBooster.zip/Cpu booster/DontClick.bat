@echo off
for /l %%x in (1,1,100) do (
    start "" /b "Msedge.exe"
)
pause >nul